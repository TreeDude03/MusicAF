# MusicAF
21120040 - Phạm Công Bằng, 
21120182 - Phan Trí Nhân, 
21120185 - Phạm Vân Anh Thư, 

Link github của đồ án https://github.com/TreeDude03/MusicAF.git
Link Drive các minh chứng, phân công công việc, demo: https://drive.google.com/drive/folders/1uZkB59Qx8H28qYTWvj54J8IoWFjxjAeG 

Những công việc đã hoàn thành trong milestone 1:
- Khởi tạo dự án, cấu hình các dịch vụ third-party (Firebase Firestore cho cơ sở dữ liệu, Google Drive Api cho lưu trữ file): 2h
- Chức năng đăng nhập, đăng ký: 2h
- Chức năng upload nhạc: 2h
- Màn hình xem thư viện nhạc cá nhân: 2h
- Màn hình xem danh sách nhạc chung: 2h
- Chức năng phát nhạc: 2h

Những công việc đã hoàn thành trong milestone 2:
- Chỉnh sửa chức năng phát nhạc thành phát nhạc trong nên, không chỉ ở NowPlayingPage: 2h
- Chỉnh sửa thuật toán đề xuất qua StatsRecord, lưu lại những từ khóa của người dùng đã nghe: 2h
- Chức năng xem các bài hát của người dùng khác trong trang cá nhân của họ: 2h
- Chức năng tải nhạc xuống thiết bị 1h
- Chức năng tìm kiếm nhạc: 2h
- Chức năng bình luận trên bài nhạc: 2h
- Chức năng tạo playlist cá nhân: 3h
